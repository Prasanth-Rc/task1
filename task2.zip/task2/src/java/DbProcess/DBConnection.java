/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DbProcess;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author DELL
 */
public class DBConnection {

    private final String strDBURL = "jdbc:postgresql://localhost:5433/task2";
    private final String strDBUserName = "postgres";
    private final String strDBPassword = "postgres";
    private Connection con = null;
    private Statement stmt = null;

    private Statement createNewConnection() {
        try {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(strDBURL, strDBUserName, strDBPassword);
            stmt = con.createStatement();
//            System.out.println(" Connection and statement created!!!");
        } catch (ClassNotFoundException cne) {
            System.out.println("Exception @ createNewConnection Class -->" + cne.getMessage());
        } catch (SQLException se) {
            System.out.println("Exception @ createNewConnection SQL  -->" + se.getMessage());
        }
        return stmt;
    }

    public long executeStmt(String strSql) {
        long lngRowNos = 0;
        try {
            this.createNewConnection();
//            System.out.println("strSql-->" + strSql);
            lngRowNos = stmt.executeUpdate(strSql);
//            System.out.println("lngRowNos-->" + lngRowNos);
//            System.out.println("Command executed!!!");
        } catch (SQLException se) {
            System.out.println("Exception @ createNewConnection SQL  -->" + se.getMessage());
        }
        return lngRowNos;
    }
}
