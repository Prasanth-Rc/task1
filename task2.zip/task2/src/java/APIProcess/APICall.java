package APIProcess;

import DbProcess.DBConnection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author DELL
 */
public class APICall {

    private final String API_URL = "https://dummyjson.com/products";

    public String callAPI() {
        StringBuffer strBuff = new StringBuffer();
        String strResult = "";
        String strRead = "";
        try {
            URL url = new URL(API_URL);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            BufferedReader response = new BufferedReader(new InputStreamReader(con.getInputStream()));
            int responseCode = con.getResponseCode();
            System.out.println("responseCode-->" + responseCode);
            if (responseCode == HttpURLConnection.HTTP_OK) {
                while ((strRead = response.readLine()) != null) {
//                    System.out.println("response.readLine()" + strRead);
                    strBuff.append(strRead);
                }
                strResult = strBuff.toString();
            } else {
                strResult = "Connection not established";
            }
            response.close();
            con.disconnect();

        } catch (MalformedURLException eurl) {
            System.out.println("Exception @ call API-->" + eurl.getMessage());
        } catch (IOException eio) {
            System.out.println("Exception @ call API-->" + eio.getMessage());
        }
        return strResult;
    }

    public String readData() {
        String strSql = "";
        String strResponse = "";
        long lngRowReturn = 0;
        String strResult = "Failed!!!";
        DbProcess.DBConnection db = new DBConnection();
        strResponse = this.callAPI();
//        System.out.println("strResponse -->" + strResponse);
        if (strResponse.length() > 0) {
            strSql = " DELETE FROM product_log;";
            strSql += "INSERT INTO product_log VALUES ('" + strResponse.replace("'", "`") + "',current_timestamp);";
            lngRowReturn = db.executeStmt(strSql);
            this.parseJsonData(strResponse, db);
        }
        if (lngRowReturn > 0) {
            strResult = "Successfully Inserted!!!";
        }
        return strResult;
    }

    public String parseJsonData(String strJsonData, DBConnection db) {
        int intId = 0, intRating = 0, intStock = 0, intWeight = 0, intMinimumOrderQuantity = 0;
        String strTitle = "", strDescription = "", strCategory = "", strBrand = "", strSKU = "", strWarrantyInformation = "",
                strShippingInformation = "", strAvailabilityStatus = "",
                StrReturnPolicy = "", strThumbnail = "",
                strCreatedAt = "", strUpdatedAt = "", strBarCode = "", strQRCode = "",
                strImages = "", strTags;
        String strComment = "", strDate = "", strReviewerName = "", strReviewerEmail = "";
        double ldblPrice = 0, ldblDiscountPercentage = 0, ldblRatings = 0;
        double ldblWidth = 0, ldblHeight = 0, ldblDepth = 0;
        String strSql = "";
        long lngRowReturn = 0;
        try {
            if (strJsonData.length() > 0) {
                strSql = "delete from public.producttags; ";
                strSql += "delete from public.productimage; ";
                strSql += "delete from public.productreview; ";
                strSql += "delete from public.productmaster; ";

                lngRowReturn = db.executeStmt(strSql);
                JSONParser parser = new JSONParser();
                JSONObject jsonObject = (JSONObject) parser.parse(strJsonData);
                JSONArray jsonArray = (JSONArray) jsonObject.get("products");
                int count = jsonArray.size();
                System.out.println(" product count -->" + count);
                for (int i = 0; i < count; i++) {
                    JSONObject jsonproduct = (JSONObject) jsonArray.get(i);
                    intId = Integer.parseInt(jsonproduct.get("id").toString());
                    strTitle = jsonproduct.get("title").toString();
                    strDescription = jsonproduct.get("description").toString();
                    strCategory = jsonproduct.get("category").toString();
                    ldblPrice = Double.parseDouble(jsonproduct.get("price").toString());
                    ldblDiscountPercentage = Double.parseDouble(jsonproduct.get("discountPercentage").toString());
                    ldblRatings = Double.parseDouble(jsonproduct.get("rating").toString());
                    try {
                        strBrand = jsonproduct.get("brand").toString();
                    } catch (Exception e) {
                        strBrand = "";
                    }
                    strSKU = jsonproduct.get("sku").toString();

                    JSONObject jsonDimension = (JSONObject) jsonproduct.get("dimensions");
                    ldblWidth = Double.parseDouble(jsonDimension.get("width").toString());
                    ldblHeight = Double.parseDouble(jsonDimension.get("height").toString());
                    ldblDepth = Double.parseDouble(jsonDimension.get("depth").toString());

                    strWarrantyInformation = jsonproduct.get("warrantyInformation").toString();
                    strShippingInformation = jsonproduct.get("shippingInformation").toString();
                    strAvailabilityStatus = jsonproduct.get("availabilityStatus").toString();
                    StrReturnPolicy = jsonproduct.get("returnPolicy").toString();
                    StrReturnPolicy = jsonproduct.get("minimumOrderQuantity").toString();

                    JSONObject jsonMeta = (JSONObject) jsonproduct.get("meta");
                    strCreatedAt = jsonMeta.get("createdAt").toString();
                    strUpdatedAt = jsonMeta.get("updatedAt").toString();
                    strBarCode = jsonMeta.get("barcode").toString();
                    strQRCode = jsonMeta.get("qrCode").toString();

                    strThumbnail = jsonproduct.get("thumbnail").toString();
                    System.out.println("intId -->" + intId);
                    strSql = "INSERT INTO public.productmaster(id, title, description, category, price, discountpercentage, "
                            + " rating, stock, brand, sku, "
                            + " weight, width, height, depth, warrantyinformation, shippinginformation, availabilitystatus, "
                            + " returnpolicy, minimumorderquantity, createdat, updatedat, barcode, qrcode, thumbnail)"
                            + " VALUES (" + intId + ",'" + strTitle.replaceAll("'", "`") + "','" + strDescription.replaceAll("'", "`") + "','" + strCategory + "',"
                            + ldblPrice + "," + ldblDiscountPercentage + "," + ldblRatings + "," + intStock + ",'" + strBrand + "',"
                            + "'" + strSKU + "'," + intWeight + "," + ldblWidth + "," + ldblHeight + "," + ldblDepth + ",'" + strWarrantyInformation.replaceAll("'", "`") + "'"
                            + ",'" + strShippingInformation.replaceAll("'", "`") + "'" + ",'" + strAvailabilityStatus + "'" + ",'" + StrReturnPolicy.replaceAll("'", "`") + "',"
                            + intMinimumOrderQuantity + ",'" + strCreatedAt + "','" + strUpdatedAt + "','" + strBarCode + "','" + strQRCode.replaceAll("'", "`") + "','" + strThumbnail.replaceAll("'", "`") + "')";
                    lngRowReturn = db.executeStmt(strSql);
                    if (lngRowReturn > 0) {
                        JSONArray jsonTagArray = (JSONArray) jsonproduct.get("tags");
                        for (int j = 0; j < jsonTagArray.size(); j++) {
                            strSql = "INSERT INTO public.producttags(id, tag)"
                                    + " VALUES (" + intId + ",'" + jsonTagArray.get(j).toString().replaceAll("'", "`") + "')";
                            lngRowReturn = db.executeStmt(strSql);
                        }
                    }
                    if (lngRowReturn > 0) {
                        JSONArray jsonReviewArray = (JSONArray) jsonproduct.get("reviews");
                        for (int k = 0; k < jsonReviewArray.size(); k++) {
                            JSONObject jsonReview = (JSONObject) jsonReviewArray.get(k);
                            intRating = Integer.parseInt(jsonReview.get("rating").toString());
                            strComment = jsonReview.get("comment").toString().toString().replaceAll("'", "`");
                            strDate = jsonReview.get("date").toString().replaceAll("'", "`");
                            strReviewerName = jsonReview.get("reviewerName").toString().replaceAll("'", "`");
                            strReviewerEmail = jsonReview.get("reviewerEmail").toString().replaceAll("'", "`");
                            strSql = "INSERT INTO public.productreview(id, rating,comment,date,reviewerName,reviewerEmail)"
                                    + " VALUES (" + intId + "," + intRating + ",'" + strComment + "','"
                                    + strDate + "','" + strReviewerName + "','" + strReviewerEmail + "')";
                            lngRowReturn = db.executeStmt(strSql);
                        }
                    }
                    if (lngRowReturn > 0) {
                        JSONArray jsonImagesArray = (JSONArray) jsonproduct.get("images");
                        for (int l = 0; l < jsonImagesArray.size(); l++) {
                            strSql = "INSERT INTO public.productimage(id, imagepath)"
                                    + " VALUES (" + intId + ",'" + jsonImagesArray.get(l).toString().replaceAll("'", "`") + "')";
                            lngRowReturn = db.executeStmt(strSql);
                        }
                    }
                }
            }
        } catch (ParseException pe) {
            System.out.println("Exception @ readData-->" + pe.getMessage());
        }
        return "Updated!!!";
    }

    public static void main(String[] args) {
        APICall ac = new APICall();
        System.out.println("result-->" + ac.readData());
    }

}
