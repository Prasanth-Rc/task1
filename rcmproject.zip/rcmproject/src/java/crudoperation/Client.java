package crudoperation;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import dbconnection.DatabaseConnection;
import java.sql.ResultSetMetaData;
import java.util.LinkedHashMap;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import net.sf.json.JSONObject;

public class Client extends HttpServlet {

    private HttpServletRequest request;

    public void setRequest(HttpServletRequest request) {
        this.request = request;
    }

    public String saveClient() {
        String resultMessage = "";
        String clientName = request.getParameter("clientName");
        System.out.println("clientName   " + clientName);
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        JSONObject jsonResponse = new JSONObject();
        String sql = "INSERT INTO details.clientdetails (client_name, status, created_at, created_by) VALUES (?, '1', CURRENT_DATE, ?)";

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            stmt.setString(1, clientName);
            stmt.setInt(2, userId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                jsonResponse.put("resultstatus", 1);
                jsonResponse.put("result", "Client saved successfully!");
            } else {
                jsonResponse.put("resultstatus", 0);
                jsonResponse.put("result", "Failed to save client.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            jsonResponse.put("resultstatus", 0);
            jsonResponse.put("result", "Error occurred while saving client: " + e.getMessage());
        }

        return jsonResponse.toString();
    }

    public String updateClient() {
        String resultMessage = "";
        String clientName = request.getParameter("clientName");
        int clientId = Integer.parseInt(request.getParameter("clientid"));
        System.out.println("clientName   " + clientName);
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        JSONObject jsonResponse = new JSONObject();
        String sql = "UPDATE details.clientdetails SET client_name = ?, updated_at = CURRENT_DATE, updated_by = ? WHERE client_id = ?";

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            stmt.setString(1, clientName);
            stmt.setInt(2, userId);
            stmt.setInt(3, clientId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                jsonResponse.put("resultstatus", 1);
                jsonResponse.put("result", "Client Update successfully!");
            } else {
                jsonResponse.put("resultstatus", 0);
                jsonResponse.put("result", "Failed to Update client.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            jsonResponse.put("resultstatus", 0);
            jsonResponse.put("result", "Error occurred while Updating client: " + e.getMessage());
        }

        return jsonResponse.toString();
    }

    public String deleteClient() {
        String resultMessage = "";
        int clientId = Integer.parseInt(request.getParameter("clientId"));
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        JSONObject jsonResponse = new JSONObject();
        String sql = "UPDATE details.clientdetails SET status = 2, deleted_at = CURRENT_DATE, deleted_by = ? WHERE client_id = ?";

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            stmt.setInt(1, userId);
            stmt.setInt(2, clientId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                jsonResponse.put("resultstatus", 1);
                jsonResponse.put("result", "Client Delete successfully!");
            } else {
                jsonResponse.put("resultstatus", 0);
                jsonResponse.put("result", "Failed to Delete client.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            jsonResponse.put("resultstatus", 0);
            jsonResponse.put("result", "Error occurred while Deleting client: " + e.getMessage());
        }

        return jsonResponse.toString();
    }

    public Map<String, Map<String, String>> getDetails() {
        Map<String, Map<String, String>> clientDetailsMap = new LinkedHashMap<>();
        String sql = "SELECT CD.client_id, CD.client_name, CD.created_at, S.username "
                + " FROM details.clientdetails CD "
                + " JOIN usermanager.sigindetails S ON S.userid = CAST(CD.created_by AS INTEGER) "
                + " WHERE status = 1 "
                + " ORDER BY CD.client_name, CD.created_at ";

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            try (ResultSet rs = stmt.executeQuery()) {
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                int rowNumber = 0;

                while (rs.next()) {
                    rowNumber++;
                    Map<String, String> rowData = new HashMap<>();

                    for (int i = 1; i <= columnCount; i++) {
                        String columnName = metaData.getColumnName(i);
                        String columnValue = rs.getString(i);
                        rowData.put(columnName, columnValue);
                    }

                    clientDetailsMap.put(String.valueOf(rowNumber), rowData);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            Map<String, String> errorDetails = new HashMap<>();
            errorDetails.put("error", "Error fetching client details: " + e.getMessage());
            clientDetailsMap.put("error", errorDetails);
        }
        System.out.println(clientDetailsMap);
        return clientDetailsMap;
    }
}
