package crudoperation;

import dbconnection.DatabaseConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import net.sf.json.JSONObject;

public class Shop extends HttpServlet {

    private HttpServletRequest request;
    private String filter = "";

    public void setRequest(HttpServletRequest request) {
        this.request = request;
        try {
            if (request.getParameter("filter") != null) {
                setFilter(request.getParameter("filter").trim().toUpperCase());
            }
        } catch (Exception e) {
            this.filter = "";
        }
    }

    private void setFilter(String filter) {
        this.filter = filter;
    }

    public String saveShop() {
        String resultMessage = "";
        int clientId = Integer.parseInt(request.getParameter("clientId"));
        String shopName = request.getParameter("shopName");
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        JSONObject jsonResponse = new JSONObject();
        String sql = "INSERT INTO details.shop_details (client_id, shop_name, status, created_at, created_by) VALUES (?, ?, '1', CURRENT_DATE, ?)";

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            stmt.setInt(1, clientId);
            stmt.setString(2, shopName);
            stmt.setInt(3, userId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                jsonResponse.put("resultstatus", 1);
                jsonResponse.put("result", "Shop saved successfully!");
            } else {
                jsonResponse.put("resultstatus", 0);
                jsonResponse.put("result", "Failed to save Shop.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            jsonResponse.put("resultstatus", 0);
            jsonResponse.put("result", "Error occurred while saving Shop: " + e.getMessage());
        }

        return jsonResponse.toString();
    }

    public String updateShop() {
        String resultMessage = "";
        int clientId = Integer.parseInt(request.getParameter("clientId"));
        int shopId = Integer.parseInt(request.getParameter("shopid"));
        String shopName = request.getParameter("shopName");
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        JSONObject jsonResponse = new JSONObject();
        String sql = "UPDATE details.shop_details SET client_id = ?, shop_name =?, updated_at = CURRENT_DATE, updated_by = ? WHERE shop_id = ?";

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            stmt.setInt(1, clientId);
            stmt.setString(2, shopName);
            stmt.setInt(3, userId);
            stmt.setInt(4, shopId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                jsonResponse.put("resultstatus", 1);
                jsonResponse.put("result", "Shop Updated successfully!");
            } else {
                jsonResponse.put("resultstatus", 0);
                jsonResponse.put("result", "Failed to Update.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            jsonResponse.put("resultstatus", 0);
            jsonResponse.put("result", "Error occurred while Update Shop: " + e.getMessage());
        }

        return jsonResponse.toString();
    }

    public String deleteShop() {
        String resultMessage = "";
        int shopId = Integer.parseInt(request.getParameter("shopId"));
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        JSONObject jsonResponse = new JSONObject();
        String sql = "UPDATE details.shop_details SET status = 2, deleted_at = CURRENT_DATE, deleted_by = ? WHERE shop_id = ?";

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            stmt.setInt(1, userId);
            stmt.setInt(2, shopId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                jsonResponse.put("resultstatus", 1);
                jsonResponse.put("result", "Client saved successfully!");
            } else {
                jsonResponse.put("resultstatus", 0);
                jsonResponse.put("result", "Failed to save client.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            jsonResponse.put("resultstatus", 0);
            jsonResponse.put("result", "Error occurred while saving client: " + e.getMessage());
        }

        return jsonResponse.toString();
    }

    public Map<String, Map<String, String>> getDetails() {
        Map<String, Map<String, String>> shopDetailsMap = new LinkedHashMap<>();
        String sql = " SELECT SD.shop_id, SD.client_id, SD.shop_name, CD.client_name, SD.created_at, S.username "
                + " FROM details.shop_details SD "
                + " JOIN details.clientdetails CD ON CD.client_id = SD.client_id "
                + " JOIN usermanager.sigindetails S ON S.userid = CAST(SD.created_by AS INTEGER) "
                + " WHERE SD.status = 1 "
                + " ORDER BY SD.shop_name, SD.created_at,  CD.client_name";

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            try (ResultSet rs = stmt.executeQuery()) {
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                int rowNumber = 0;

                while (rs.next()) {
                    rowNumber++;
                    Map<String, String> rowData = new HashMap<>();

                    for (int i = 1; i <= columnCount; i++) {
                        String columnName = metaData.getColumnName(i);
                        String columnValue = rs.getString(i);
                        rowData.put(columnName, columnValue);
                    }

                    shopDetailsMap.put(String.valueOf(rowNumber), rowData);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            Map<String, String> errorDetails = new HashMap<>();
            errorDetails.put("error", "Error fetching client details: " + e.getMessage());
            shopDetailsMap.put("error", errorDetails);
        }
        System.out.println(shopDetailsMap);
        return shopDetailsMap;
    }

    public Map<String, Map<String, String>> getClient() {
        Map<String, Map<String, String>> clientDetailsMap = new LinkedHashMap<>();
        String sql = " SELECT CD.client_id, CD.client_name "
                + " FROM details.clientdetails CD "
                + " WHERE CD.status = 1 AND UCASE(REPLACE(CD.client_name,' ','')) LIKE UCASE(REPLACE('% " + filter + " %',' ','')) "
                + " ORDER BY CD.client_id, CD.client_name ";

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            try (ResultSet rs = stmt.executeQuery()) {
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                int rowNumber = 0;

                while (rs.next()) {
                    rowNumber++;
                    Map<String, String> rowData = new HashMap<>();

                    for (int i = 1; i <= columnCount; i++) {
                        String columnName = metaData.getColumnName(i);
                        String columnValue = rs.getString(i);
                        rowData.put(columnName, columnValue);
                    }

                    clientDetailsMap.put(String.valueOf(rowNumber), rowData);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            Map<String, String> errorDetails = new HashMap<>();
            errorDetails.put("error", "Error fetching client details: " + e.getMessage());
            clientDetailsMap.put("error", errorDetails);
        }
        System.out.println(clientDetailsMap);
        return clientDetailsMap;
    }

}
