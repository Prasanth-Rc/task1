/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crudoperation;

import dbconnection.DatabaseConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import net.sf.json.JSONObject;

/**
 *
 * @author DELL
 */
public class Collection {

    private HttpServletRequest request;
    private String filter = "";

    public void setRequest(HttpServletRequest request) {
        this.request = request;
        try {
            if (request.getParameter("filter") != null) {
                setFilter(request.getParameter("filter").trim().toUpperCase());
            }
        } catch (Exception e) {
            this.filter = "";
        }
    }

    private void setFilter(String filter) {
        this.filter = filter;
    }
    public String saveCollection() {
        String resultMessage = "";
        String sql = "";
        int transId = Integer.parseInt(request.getParameter("transId"));
        String amount = request.getParameter("countingAmount");
        String denominations = request.getParameter("denominations");
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        JSONObject jsonResponse = new JSONObject();

        boolean isValidUser = false;

        sql = "SELECT trans_id FROM details.daily_collection WHERE trans_id = ? AND status = 1";

        try {
            ResultSet rs = DatabaseConnection.executeQuery(sql, transId);

            if (rs.next()) {
                isValidUser = true;
            }
            rs.close();
            System.out.println("--" + sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (isValidUser == false) {

            sql = "INSERT INTO details.daily_collection (trans_id, total_amount, status, denominations, created_at, created_by) "
                    + " VALUES ( ?,  ?, 1, ?, CURRENT_TIMESTAMP, ?)";

            try (DatabaseConnection dbConn = new DatabaseConnection();
                    PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

                stmt.setInt(1, transId);
                stmt.setString(2, amount);
                stmt.setString(3, denominations);
                stmt.setInt(4, userId);

                int rowsAffected = stmt.executeUpdate();
                System.out.println("--" + sql);
                if (rowsAffected > 0) {
                    jsonResponse.put("resultstatus", 1);
                    jsonResponse.put("result", "Collection saved successfully!");
                } else {
                    jsonResponse.put("resultstatus", 0);
                    jsonResponse.put("result", "Failed to save Collection.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                jsonResponse.put("resultstatus", 0);
                jsonResponse.put("result", "Error occurred while saving Collection: " + e.getMessage());
            }
        } else {
            sql = " UPDATE details.daily_collection "
                    + " SET total_amount = (total_amount::INT + ?::INT),status=1, denominations=?, updated_at = CURRENT_TIMESTAMP, updated_by = ? "
                    + " WHERE trans_id = ?";
            try (DatabaseConnection dbConn = new DatabaseConnection();
                    PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

                stmt.setString(1, amount);
                stmt.setString(2, denominations);
                stmt.setInt(3, userId);
                stmt.setInt(4, transId);

                int rowsAffected = stmt.executeUpdate();
                System.out.println("--" + sql);
                if (rowsAffected > 0) {
                    jsonResponse.put("resultstatus", 1);
                    jsonResponse.put("result", "Collection Updated successfully!");
                } else {
                    jsonResponse.put("resultstatus", 0);
                    jsonResponse.put("result", "Failed to Update Collection.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                jsonResponse.put("resultstatus", 0);
                jsonResponse.put("result", "Error occurred while Updating Collection: " + e.getMessage());
            }
        }
        System.out.println("result" + jsonResponse.toString());
        return jsonResponse.toString();
    }

    public String deleteCollection() {
        String resultMessage = "";
        int transId = Integer.parseInt(request.getParameter("transId"));
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        JSONObject jsonResponse = new JSONObject();
        String sql = "UPDATE details.daily_collection SET status = 2, deleted_at = CURRENT_DATE, deleted_by = ? WHERE trans_id = ?";

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            stmt.setInt(1, userId);
            stmt.setInt(2, transId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                jsonResponse.put("resultstatus", 1);
                jsonResponse.put("result", "Transaction Delete successfully!");
            } else {
                jsonResponse.put("resultstatus", 0);
                jsonResponse.put("result", "Failed to Delete Transaction.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            jsonResponse.put("resultstatus", 0);
            jsonResponse.put("result", "Error occurred while Delete Transaction: " + e.getMessage());
        }

        return jsonResponse.toString();
    }

    public Map<String, Map<String, String>> getDetails() {
        String transdate = request.getParameter("transDate");
        int shopId = Integer.parseInt(request.getParameter("shopId"));
        Map<String, Map<String, String>> transactionDetailsMap = new LinkedHashMap<>();
        String sql = " SELECT TD.trans_id, TD.shop_id, SD.shop_name, CD.client_name, TD.request_amount, TO_CHAR(TD.trans_date,'dd-mm-yyyy') AS trans_date, "
                + " (COALESCE(TD.request_amount::INTEGER,0) -  COALESCE(DC.total_amount::INTEGER,0)) AS pendingamount,COALESCE(DC.total_amount,'0') AS total_amount "
                + " FROM details.transactiondetails TD "
                + " LEFT JOIN details.daily_collection DC ON TD.trans_id = DC.trans_id  "
                + " JOIN details.shop_details SD ON SD.shop_id = TD.shop_id "
                + " JOIN details.clientdetails CD ON CD.client_id = SD.client_id "
                + " WHERE TD.status = 1 AND TD.trans_date = TO_DATE('" + transdate + "','DD-MM-YYYY') AND TD.shop_id =" + shopId;

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            try (ResultSet rs = stmt.executeQuery()) {
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                int rowNumber = 0;

                while (rs.next()) {
                    rowNumber++;
                    Map<String, String> rowData = new HashMap<>();

                    for (int i = 1; i <= columnCount; i++) {
                        String columnName = metaData.getColumnName(i);
                        String columnValue = rs.getString(i);
                        rowData.put(columnName, columnValue);
                    }

                    transactionDetailsMap.put(String.valueOf(rowNumber), rowData);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            Map<String, String> errorDetails = new HashMap<>();
            errorDetails.put("error", "Error fetching client details: " + e.getMessage());
            transactionDetailsMap.put("error", errorDetails);
        }
        return transactionDetailsMap;
    }

    public Map<String, Map<String, String>> getShop() {
        Map<String, Map<String, String>> shopDetailsMap = new LinkedHashMap<>();
        String sql = " SELECT TD.trans_id, SD.shop_id, SD.shop_name, TD.request_amount, (COALESCE(TD.request_amount::INTEGER,0) -  COALESCE(DC.total_amount::INTEGER,0)) AS pendingamount "
                + " FROM details.shop_details SD "
                + " JOIN details.transactiondetails TD ON TD.shop_id = SD.shop_id "
                + " LEFT JOIN details.daily_collection DC ON TD.trans_id = DC.trans_id "
                + " WHERE SD.status = 1 AND UCASE(REPLACE(SD.shop_name,' ','')) LIKE UCASE(REPLACE('% " + filter + " %',' ','')) "
                + " ORDER BY SD.shop_id, SD.shop_name ";

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            try (ResultSet rs = stmt.executeQuery()) {
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                int rowNumber = 0;

                while (rs.next()) {
                    rowNumber++;
                    Map<String, String> rowData = new HashMap<>();

                    for (int i = 1; i <= columnCount; i++) {
                        String columnName = metaData.getColumnName(i);
                        String columnValue = rs.getString(i);
                        rowData.put(columnName, columnValue);
                    }

                    shopDetailsMap.put(String.valueOf(rowNumber), rowData);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            Map<String, String> errorDetails = new HashMap<>();
            errorDetails.put("error", "Error fetching client details: " + e.getMessage());
            shopDetailsMap.put("error", errorDetails);
        }
        return shopDetailsMap;
    }
}
