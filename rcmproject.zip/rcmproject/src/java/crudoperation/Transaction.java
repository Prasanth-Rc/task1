/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crudoperation;

import dbconnection.DatabaseConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import net.sf.json.JSONObject;

/**
 *
 * @author DELL
 */
public class Transaction {

    private HttpServletRequest request;
    private String filter = "";

    public void setRequest(HttpServletRequest request) {
        this.request = request;
        try {
            if (request.getParameter("filter") != null) {
                setFilter(request.getParameter("filter").trim().toUpperCase());
            }
        } catch (Exception e) {
            this.filter = "";
        }
    }

    private void setFilter(String filter) {
        this.filter = filter;
    }

    public String saveTransaction() {
        String resultMessage = "";
        int shopId = Integer.parseInt(request.getParameter("shopId"));
        String amount = request.getParameter("amount");
        String transdate = request.getParameter("transDate");
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        JSONObject jsonResponse = new JSONObject();
        String sql = "INSERT INTO details.transactiondetails (shop_id, request_amount, trans_date, status, created_at, created_by) VALUES (?, ?, TO_DATE(?,'dd-mm-yyyy'), '1', CURRENT_DATE, ?)";

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            stmt.setInt(1, shopId);
            stmt.setString(2, amount);
            stmt.setString(3, transdate);
            stmt.setInt(4, userId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                jsonResponse.put("resultstatus", 1);
                jsonResponse.put("result", "Transaction saved successfully!");
            } else {
                jsonResponse.put("resultstatus", 0);
                jsonResponse.put("result", "Failed to save Shop.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            jsonResponse.put("resultstatus", 0);
            jsonResponse.put("result", "Error occurred while saving Transaction: " + e.getMessage());
        }

        return jsonResponse.toString();
    }

    public String updateTransaction() {
        String resultMessage = "";
        int transId = Integer.parseInt(request.getParameter("transId"));
        int shopId = Integer.parseInt(request.getParameter("shopId"));
        String amount = request.getParameter("amount");
        String transdate = request.getParameter("transDate");
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        JSONObject jsonResponse = new JSONObject();
        String sql = "UPDATE details.transactiondetails SET shop_id = ?, request_amount =?, trans_date=TO_DATE(?,'dd-mm-yyyy'), updated_at = CURRENT_DATE, updated_by = ? WHERE trans_id = ?";

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            stmt.setInt(1, shopId);
            stmt.setString(2, amount);
            stmt.setString(3, transdate);
            stmt.setInt(4, userId);
            stmt.setInt(5, transId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                jsonResponse.put("resultstatus", 1);
                jsonResponse.put("result", "Transaction Updated successfully!");
            } else {
                jsonResponse.put("resultstatus", 0);
                jsonResponse.put("result", "Failed to Update.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            jsonResponse.put("resultstatus", 0);
            jsonResponse.put("result", "Error occurred while Update Transaction: " + e.getMessage());
        }

        return jsonResponse.toString();
    }

    public String deleteTransaction() {
        String resultMessage = "";
        int transId = Integer.parseInt(request.getParameter("transId"));
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        JSONObject jsonResponse = new JSONObject();
        String sql = "UPDATE details.transactiondetails SET status = 2, deleted_at = CURRENT_DATE, deleted_by = ? WHERE trans_id = ?";

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            stmt.setInt(1, userId);
            stmt.setInt(2, transId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                jsonResponse.put("resultstatus", 1);
                jsonResponse.put("result", "Transaction Delete successfully!");
            } else {
                jsonResponse.put("resultstatus", 0);
                jsonResponse.put("result", "Failed to Delete Transaction.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            jsonResponse.put("resultstatus", 0);
            jsonResponse.put("result", "Error occurred while Delete Transaction: " + e.getMessage());
        }

        return jsonResponse.toString();
    }

    public Map<String, Map<String, String>> getDetails() {
        Map<String, Map<String, String>> transactionDetailsMap = new LinkedHashMap<>();
        String sql = " SELECT TD.trans_id, TD.shop_id, SD.shop_name, CD.client_name, TD.request_amount, TO_CHAR(TD.trans_date,'dd-mm-yyyy') AS trans_date, TO_CHAR(TD.created_at,'dd-mm-yyyy') AS created_at, S.username "
                + " FROM details.transactiondetails TD  "
                + " JOIN details.shop_details SD ON SD.shop_id = TD.shop_id "
                + " JOIN details.clientdetails CD ON CD.client_id = SD.client_id "
                + " JOIN usermanager.sigindetails S ON S.userid = CAST(TD.created_by AS INTEGER) "
                + " WHERE TD.status = 1 "
                + " ORDER BY TD.trans_date DESC, SD.shop_name, CD.client_name, TD.request_amount";

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            try (ResultSet rs = stmt.executeQuery()) {
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                int rowNumber = 0;

                while (rs.next()) {
                    rowNumber++;
                    Map<String, String> rowData = new HashMap<>();

                    for (int i = 1; i <= columnCount; i++) {
                        String columnName = metaData.getColumnName(i);
                        String columnValue = rs.getString(i);
                        rowData.put(columnName, columnValue);
                    }

                    transactionDetailsMap.put(String.valueOf(rowNumber), rowData);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            Map<String, String> errorDetails = new HashMap<>();
            errorDetails.put("error", "Error fetching client details: " + e.getMessage());
            transactionDetailsMap.put("error", errorDetails);
        }
        return transactionDetailsMap;
    }

    public Map<String, Map<String, String>> getShop() {
        Map<String, Map<String, String>> shopDetailsMap = new LinkedHashMap<>();
        String sql = " SELECT SD.shop_id, SD.shop_name "
                + " FROM details.shop_details SD "
                + " WHERE SD.status = 1 AND UCASE(REPLACE(SD.shop_name,' ','')) LIKE UCASE(REPLACE('% " + filter + " %',' ','')) "
                + " ORDER BY SD.shop_id, SD.shop_name ";

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            try (ResultSet rs = stmt.executeQuery()) {
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                int rowNumber = 0;

                while (rs.next()) {
                    rowNumber++;
                    Map<String, String> rowData = new HashMap<>();

                    for (int i = 1; i <= columnCount; i++) {
                        String columnName = metaData.getColumnName(i);
                        String columnValue = rs.getString(i);
                        rowData.put(columnName, columnValue);
                    }

                    shopDetailsMap.put(String.valueOf(rowNumber), rowData);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            Map<String, String> errorDetails = new HashMap<>();
            errorDetails.put("error", "Error fetching client details: " + e.getMessage());
            shopDetailsMap.put("error", errorDetails);
        }
        return shopDetailsMap;
    }
}
