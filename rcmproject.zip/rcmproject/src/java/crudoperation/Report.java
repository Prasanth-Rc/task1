/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crudoperation;

import dbconnection.DatabaseConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author DELL
 */
public class Report {
    
    private HttpServletRequest request;

    public void setRequest(HttpServletRequest request) {
        this.request = request;
    }

    public Map<String, Map<String, String>> getDetails() {
        Map<String, Map<String, String>> transactionDetailsMap = new LinkedHashMap<>();
        String sql = " select CD.client_name, SD.shop_name, TD.request_amount, DC.total_amount, (TD.request_amount::INTEGER -  DC.total_amount::INTEGER) AS pendingamount "
                + " from details.daily_collection DC "
                + " JOIN details.transactiondetails TD ON TD.trans_id = DC.trans_id "
                + " JOIN details.shop_details SD On SD.shop_id = TD.shop_id "
                + " JOIN details.clientdetails CD ON CD.client_id = SD.client_id "
                + " WHERE DC.status = 1"
                + " ORDER BY CD.client_name, SD.shop_name ";

        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement stmt = dbConn.getConnection().prepareStatement(sql)) {

            try (ResultSet rs = stmt.executeQuery()) {
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                int rowNumber = 0;

                while (rs.next()) {
                    rowNumber++;
                    Map<String, String> rowData = new HashMap<>();

                    for (int i = 1; i <= columnCount; i++) {
                        String columnName = metaData.getColumnName(i);
                        String columnValue = rs.getString(i);
                        rowData.put(columnName, columnValue);
                    }

                    transactionDetailsMap.put(String.valueOf(rowNumber), rowData);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            Map<String, String> errorDetails = new HashMap<>();
            errorDetails.put("error", "Error fetching client details: " + e.getMessage());
            transactionDetailsMap.put("error", errorDetails);
        }
        return transactionDetailsMap;
    }
}
