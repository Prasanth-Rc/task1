package dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseConnection implements AutoCloseable {

    private static final String URL = "jdbc:postgresql://localhost:5432/yourdatabase";
    private static final String USER = "postgres";
    private static final String PASSWORD = "postgres";

    private Connection connection;

    public DatabaseConnection() throws SQLException {
        try {
            Class.forName("org.postgresql.Driver");
            this.connection = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new SQLException("PostgreSQL JDBC Driver not found", e);
        }
    }

    public Connection getConnection() {
        return connection;
    }

    public static int executeUpdate(String sql, Object... params) throws SQLException {
        try (DatabaseConnection dbConn = new DatabaseConnection();
                PreparedStatement pstmt = dbConn.getConnection().prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                pstmt.setObject(i + 1, params[i]);
            }

            return pstmt.executeUpdate();
        }
    }

    public static ResultSet executeQuery(String sql, Object... params) throws SQLException {
        DatabaseConnection dbConn = new DatabaseConnection();
        PreparedStatement pstmt = dbConn.getConnection().prepareStatement(sql);
        for (int i = 0; i < params.length; i++) {
            pstmt.setObject(i + 1, params[i]);
        }

        return pstmt.executeQuery();
    }

    public void close() throws SQLException {
        if (connection != null) {
            connection.close();
        }
    }
}
