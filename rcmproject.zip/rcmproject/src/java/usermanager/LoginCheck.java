package usermanager;

import java.sql.ResultSet;
import java.sql.SQLException;

import dbconnection.DatabaseConnection;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;

public class LoginCheck {

    private javax.servlet.http.HttpServletRequest request;

    public void setRequest(javax.servlet.http.HttpServletRequest request) {

        this.request = request;
    }

    public boolean userCheck(String userName, String passWord) {
        boolean isValidUser = false;

        String sql = "SELECT userid FROM usermanager.sigindetails WHERE username = ? AND userpassword = ?";

        try {
            ResultSet rs = DatabaseConnection.executeQuery(sql, userName, passWord);

            if (rs.next()) {
                isValidUser = true;
                int userId = rs.getInt("userid");
                HttpSession session = request.getSession(true);
                session.setAttribute("userId", userId);
            }
            rs.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return isValidUser;
    }
}
