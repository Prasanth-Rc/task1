package usermanager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dbconnection.DatabaseConnection;

public class Registration {

    public boolean isUsernameTaken(String email) {
        String query = "SELECT 1 FROM usermanager.sigindetails WHERE email = ?";
        try (DatabaseConnection connection = new DatabaseConnection();
                PreparedStatement pstmt = connection.getConnection().prepareStatement(query)) {
            pstmt.setString(1, email);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next(); // If there's a record, the username is taken
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // In case of an error, assume username is available
        }
    }

    public boolean registerUser(String username, String password, String email) throws SQLException {
        if (isUsernameTaken(email)) {
            return false;
        }

        String insertQuery = "INSERT INTO usermanager.sigindetails (username, userpassword, email) VALUES (?, ?, ?)";
        try (DatabaseConnection connection = new DatabaseConnection();
                PreparedStatement pstmt = connection.getConnection().prepareStatement(insertQuery)) {

            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setString(3, email);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
